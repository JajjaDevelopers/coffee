$(document).ready(function () {
  setTimeout(function() {
        $(".messageAlert").fadeOut("slow");
      }, 8000);
});